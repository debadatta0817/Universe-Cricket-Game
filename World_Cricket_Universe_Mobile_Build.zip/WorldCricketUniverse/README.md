# World Cricket Universe — Android starter project

A native Android / Jetpack Compose prototype for the user's cricket franchise-management game.

## Included in this build
- Premium dark sports-game UI
- Home dashboard
- RCB squad room and role filters
- Player auction/signing prototype
- Featured global franchise directory
- Match centre prototype
- Local career persistence using Android SharedPreferences
- User's RCB roster and custom players seeded into the app:
  - Debadatta Behera — 200 OVR
  - Ipsita Gouda — 100 OVR
  - 20-player RCB roster and approximately ₹17.2191 Cr remaining purse

## Important scope notes
This is an early playable UI prototype, not a finished commercial game.
- The auction is currently a local signing flow, not a multi-team live bidding engine.
- The match centre currently produces a quick simulated result. The full ball-by-ball engine, tactical bowler selection, scorecards, tournament fixtures, standings and playoffs still need implementation.
- The featured league directory is a starter catalogue, not every cricket league or every official squad.
- Offline career data is saved on the device.
- Online accounts, cloud saves and multiplayer are not active. They require a configured backend (for example Firebase Authentication + Firestore), privacy rules, testing and server-side validation.
- Player ratings and prices are game data, not official ratings or current market values.
- Do not use official league/team logos, player photographs, trademarks or broadcast assets without permission. Use original artwork and check licensing before publishing.

## Open in Android Studio
1. Install Android Studio and the Android SDK Platform 36.
2. Extract this folder.
3. In Android Studio choose **Open** and select this project folder.
4. Allow Gradle sync and install any prompted SDK components.
5. Run the `app` configuration on an Android device or emulator.

Build a debug APK:
- Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- Or terminal: `gradle :app:assembleDebug`

Build a Play Store Android App Bundle:
- Android Studio: **Build > Generate Signed Bundle / APK > Android App Bundle**
- Create and securely back up a release signing key.
- Select release, complete signing and generate the `.aab`.

## Before Google Play release
1. Finish all gameplay and test on multiple screen sizes and Android versions.
2. Add a real backend for online features and configure authentication, database rules, abuse prevention and account deletion.
3. Create privacy policy, Data safety answers, content rating and store listing.
4. Use original app icon, screenshots, feature graphic and licensed assets.
5. Complete Play Console testing requirements and submit the signed AAB.
6. A parent/guardian (18+) must own/manage the Play Console developer account if the developer is under 18.

## Project configuration
- Application ID: `com.worldcricket.universe`
- Version: `0.1.0` (versionCode 1)
- compileSdk / targetSdk: 36
- minSdk: 26
- Kotlin + Jetpack Compose + Material 3
