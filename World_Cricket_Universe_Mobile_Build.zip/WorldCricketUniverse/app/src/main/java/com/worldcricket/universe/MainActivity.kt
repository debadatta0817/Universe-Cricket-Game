package com.worldcricket.universe

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val Ink = Color(0xFF080D12)
private val Panel = Color(0xFF121B23)
private val Panel2 = Color(0xFF192630)
private val Lime = Color(0xFFB7F34A)
private val Muted = Color(0xFF9EADB8)
private val White = Color(0xFFF3F6F8)
private val Gold = Color(0xFFFFC857)
private val Red = Color(0xFFFF6B6B)

data class Cricketer(
    val name: String,
    val country: String,
    val role: String,
    val ovr: Int,
    val price: Double,
    val overseas: Boolean,
    val note: String = ""
)

data class Club(
    val name: String,
    val code: String,
    val league: String
)

private val clubs = listOf(
    Club("Royal Challengers Bengaluru", "RCB", "IPL"),
    Club("Mumbai Indians", "MI", "IPL"),
    Club("Chennai Super Kings", "CSK", "IPL"),
    Club("Kolkata Knight Riders", "KKR", "IPL"),
    Club("Sunrisers Hyderabad", "SRH", "IPL"),
    Club("Rajasthan Royals", "RR", "IPL"),
    Club("Punjab Kings", "PBKS", "IPL"),
    Club("Delhi Capitals", "DC", "IPL"),
    Club("Gujarat Titans", "GT", "IPL"),
    Club("Lucknow Super Giants", "LSG", "IPL"),
    Club("Sydney Sixers", "SS", "BBL"),
    Club("Perth Scorchers", "PS", "BBL"),
    Club("Brisbane Heat", "BH", "BBL"),
    Club("Melbourne Stars", "MS", "BBL"),
    Club("Lahore Qalandars", "LQ", "PSL"),
    Club("Islamabad United", "IU", "PSL"),
    Club("Peshawar Zalmi", "PZ", "PSL"),
    Club("Karachi Kings", "KK", "PSL"),
    Club("MI Cape Town", "MICT", "SA20"),
    Club("Sunrisers Eastern Cape", "SEC", "SA20"),
    Club("Joburg Super Kings", "JSK", "SA20"),
    Club("Durban's Super Giants", "DSG", "SA20"),
    Club("Trinbago Knight Riders", "TKR", "CPL"),
    Club("Guyana Amazon Warriors", "GAW", "CPL"),
    Club("Barbados Royals", "BR", "CPL"),
    Club("Saint Lucia Kings", "SLK", "CPL"),
    Club("Desert Vipers", "DV", "ILT20"),
    Club("MI Emirates", "MIE", "ILT20"),
    Club("Gulf Giants", "GG", "ILT20"),
    Club("Dubai Capitals", "DCP", "ILT20"),
    Club("Washington Freedom", "WF", "MLC"),
    Club("Texas Super Kings", "TSK", "MLC"),
    Club("MI New York", "MINY", "MLC"),
    Club("San Francisco Unicorns", "SFU", "MLC"),
    Club("Royal Challengers Bengaluru Women", "RCBW", "WPL"),
    Club("Mumbai Indians Women", "MIW", "WPL"),
    Club("Delhi Capitals Women", "DCW", "WPL"),
    Club("UP Warriorz", "UPW", "WPL"),
    Club("Gujarat Giants Women", "GGW", "WPL"),
    Club("Sydney Sixers Women", "SSW", "WBBL"),
    Club("Adelaide Strikers Women", "ASW", "WBBL"),
    Club("Perth Scorchers Women", "PSW", "WBBL"),
    Club("London Spirit", "LS", "The Hundred"),
    Club("Oval Invincibles", "OI", "The Hundred"),
    Club("Birmingham Phoenix", "BP", "The Hundred"),
    Club("Trent Rockets", "TR", "The Hundred"),
)

private fun basePlayers() = listOf(
    Cricketer("Virat Kohli","India","Batter",99,27.0,false,"RCB • Captain"),
    Cricketer("Yuzvendra Chahal","India","Bowler",91,13.0,false,"RCB"),
    Cricketer("Andre Russell","West Indies","All-rounder",94,2.0,true,"RCB"),
    Cricketer("Rohit Sharma","India","Batter",96,3.0,false,"RCB"),
    Cricketer("Jasprit Bumrah","India","Bowler",99,5.0,false,"RCB"),
    Cricketer("Rashid Khan","Afghanistan","All-rounder",98,.50,true,"RCB"),
    Cricketer("MS Dhoni","India","Wicketkeeper",94,.0001,false,"RCB"),
    Cricketer("Hardik Pandya","India","All-rounder",90,2.0,false,"RCB"),
    Cricketer("Bhuvneshwar Kumar","India","Bowler",99,5.0,false,"RCB"),
    Cricketer("Rajat Patidar","India","Batter",99,5.0,false,"RCB"),
    Cricketer("Ravindra Jadeja","India","All-rounder",96,.0000001,false,"RCB"),
    Cricketer("Mitchell Starc","Australia","Bowler",95,.17,true,"RCB"),
    Cricketer("Debadatta Behera","India","All-rounder",200,50.0,false,"CUSTOM • #17"),
    Cricketer("Ipsita Gouda","India","All-rounder",100,20.0,false,"CUSTOM • #12"),
    Cricketer("Shubman Gill","India","Batter",92,.10,false,"RCB"),
    Cricketer("AB de Villiers","South Africa","Wicketkeeper",99,.0099,true,"RCB"),
    Cricketer("Lasith Malinga","Sri Lanka","Bowler",100,.000001,true,"RCB"),
    Cricketer("Muttiah Muralitharan","Sri Lanka","Bowler",100,.0000000001,true,"RCB"),
    Cricketer("Shane Warne","Australia","Bowler",100,.0000000001,true,"RCB"),
    Cricketer("Dale Steyn","South Africa","Bowler",100,.0000000001,true,"RCB"),
    Cricketer("Suryakumar Yadav","India","Batter",96,18.0,false),
    Cricketer("David Warner","Australia","Batter",94,13.0,true),
    Cricketer("Jos Buttler","England","Wicketkeeper",96,19.0,true),
    Cricketer("Glenn Maxwell","Australia","All-rounder",94,20.0,true),
    Cricketer("Ben Stokes","England","All-rounder",93,18.0,true),
    Cricketer("Sunil Narine","West Indies","All-rounder",95,9.0,true),
    Cricketer("Trent Boult","New Zealand","Bowler",94,15.0,true),
    Cricketer("KL Rahul","India","Wicketkeeper",92,14.0,false),
    Cricketer("Rishabh Pant","India","Wicketkeeper",93,19.0,false),
    Cricketer("Chris Gayle","West Indies","Batter",98,13.0,true),
    Cricketer("Pat Cummins","Australia","Bowler",95,20.0,true),
    Cricketer("Babar Azam","Pakistan","Batter",96,18.0,true),
    Cricketer("Shaheen Shah Afridi","Pakistan","Bowler",96,16.0,true),
    Cricketer("Heinrich Klaasen","South Africa","Wicketkeeper",96,17.0,true),
    Cricketer("Faf du Plessis","South Africa","Batter",91,7.0,true),
    Cricketer("Kane Williamson","New Zealand","Batter",91,8.0,true),
    Cricketer("Ravichandran Ashwin","India","Bowler",90,5.0,false),
    Cricketer("Shakib Al Hasan","Bangladesh","All-rounder",91,7.0,true),
)

class GameStore(context: Context) {
    private val prefs = context.getSharedPreferences("wcu_save", Context.MODE_PRIVATE)
    private val all = basePlayers().associateBy { it.name }.toMutableMap()
    var rcbNames by mutableStateOf(loadNames())
        private set
    var purse by mutableDoubleStateOf(prefs.getString("rcb_purse", "17.2190989")!!.toDoubleOrNull() ?: 17.2190989)
        private set
    var season by mutableIntStateOf(prefs.getInt("season", 1))
        private set
    var lastResult by mutableStateOf(prefs.getString("last_result", "Season 1 is ready. Your RCB era begins here.") ?: "")
        private set
    var syncStatus by mutableStateOf("Offline career ready • Cloud sync needs setup")

    private fun loadNames(): List<String> {
        val saved = prefs.getString("rcb_names", null) ?: return basePlayers().filter { it.note.contains("RCB") || it.note.contains("CUSTOM") }.map { it.name }
        return try {
            val arr = JSONArray(saved)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) { basePlayers().filter { it.note.contains("RCB") || it.note.contains("CUSTOM") }.map { it.name } }
    }

    fun players() = all.values.toList()
    fun player(name: String) = all[name]
    fun rcbPlayers() = rcbNames.mapNotNull { all[it] }
    fun freeAgents() = all.values.filter { it.name !in rcbNames && it.note.isEmpty() }

    fun sign(player: Cricketer): String {
        if (player.name in rcbNames) return "Already in your RCB squad."
        if (rcbNames.size >= 30) return "Squad limit reached (30 players)."
        if (player.overseas && rcbPlayers().count { it.overseas } >= 15) return "Overseas limit reached (15 players)."
        if (purse < player.price) return "Not enough purse for this bid."
        rcbNames = rcbNames + player.name
        purse -= player.price
        save()
        return "${player.name} signed for ₹${"%.2f".format(player.price)} Cr!"
    }

    fun simulateQuickMatch(): String {
        val opponent = listOf("MI","CSK","KKR","SRH","GT","PBKS").random()
        val rcbScore = Random.nextInt(155, 226)
        val oppScore = Random.nextInt(150, 221)
        val result = if (rcbScore >= oppScore) "RCB beat $opponent by ${Random.nextInt(1,8)} wickets (simulated)." else "$opponent beat RCB by ${rcbScore.coerceAtLeast(1)} runs (simulated)."
        lastResult = result
        save()
        return result
    }

    fun save() {
        val arr = JSONArray()
        rcbNames.forEach { arr.put(it) }
        prefs.edit()
            .putString("rcb_names", arr.toString())
            .putString("rcb_purse", purse.toString())
            .putInt("season", season)
            .putString("last_result", lastResult)
            .apply()
    }

    fun resetSeason() {
        season += 1
        lastResult = "Season $season started. RCB are back in the title race."
        save()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = GameStore(applicationContext)
        setContent { WcuApp(store) }
    }
}

@Composable
fun WcuApp(store: GameStore) {
    var tab by remember { mutableStateOf("Home") }
    var notice by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var league by remember { mutableStateOf("All") }
    val navItems = listOf("Home","Squad","Auction","World","Match")
    val navIcons = listOf(Icons.Default.Dashboard,Icons.Default.Groups,Icons.Default.Gavel,Icons.Default.Public,Icons.Default.SportsCricket)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lime, onPrimary = Ink, background = Ink, surface = Panel,
            onBackground = White, onSurface = White, secondary = Gold
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal=18.dp, vertical=14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(38.dp).background(Lime, RoundedCornerShape(12.dp)), contentAlignment=Alignment.Center) {
                        Icon(Icons.Default.SportsCricket, null, tint=Ink)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("WORLD CRICKET", color=White, fontWeight=FontWeight.Black, fontSize=16.sp, letterSpacing=1.3.sp)
                        Text("UNIVERSE  •  GLOBAL EDITION", color=Lime, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.4.sp)
                    }
                    Icon(Icons.Default.CloudOff, null, tint=Muted)
                }
            },
            bottomBar = {
                NavigationBar(containerColor=Panel, contentColor=White) {
                    navItems.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected=tab==item,
                            onClick={tab=item},
                            icon={ Icon(navIcons[i], null) },
                            label={ Text(item, fontSize=10.sp) },
                            colors=NavigationBarItemDefaults.colors(
                                selectedIconColor=Ink, selectedTextColor=Lime,
                                indicatorColor=Lime, unselectedIconColor=Muted, unselectedTextColor=Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when(tab) {
                    "Home" -> HomeScreen(store, onNavigate={tab=it}, notice={notice=it})
                    "Squad" -> SquadScreen(store)
                    "Auction" -> AuctionScreen(store, notice={notice=it})
                    "World" -> WorldScreen()
                    "Match" -> MatchScreen(store, notice={notice=it})
                }
            }
            if (notice.isNotBlank()) {
                AlertDialog(
                    onDismissRequest={notice=""},
                    confirmButton={ TextButton2("CONTINUE") { notice="" } },
                    title={ Text("WCU UPDATE", color=Lime, fontWeight=FontWeight.Black) },
                    text={ Text(notice, color=White) },
                    containerColor=Panel
                )
            }
        }
    }
}

@Composable
fun TextButton2(label: String, click: () -> Unit) {
    Text(label, Modifier.clickable { click() }.padding(12.dp), color=Lime, fontWeight=FontWeight.Bold)
}

@Composable
fun HomeScreen(store: GameStore, onNavigate:(String)->Unit, notice:(String)->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item {
            Text("YOUR CRICKET EMPIRE", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.8.sp)
            Text("Build a legacy.", color=White, fontSize=30.sp, fontWeight=FontWeight.Black)
            Text("Run franchises. Sign legends. Own the world.", color=Muted, fontSize=13.sp)
        }
        item {
            Box(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(22.dp)).padding(18.dp)) {
                Column {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("YOUR FRANCHISE", color=Muted, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=1.4.sp)
                            Text("ROYAL CHALLENGERS", color=White, fontSize=18.sp, fontWeight=FontWeight.Black)
                            Text("BENGALURU", color=Lime, fontSize=23.sp, fontWeight=FontWeight.Black)
                        }
                        Box(Modifier.size(58.dp).background(Lime, CircleShape), contentAlignment=Alignment.Center) {
                            Text("RCB", color=Ink, fontWeight=FontWeight.Black, fontSize=18.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        StatPill("SQUAD","${store.rcbNames.size}/30")
                        StatPill("PURSE","₹${"%.2f".format(store.purse)} Cr")
                        StatPill("SEASON","${store.season}")
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick={onNavigate("Squad")}, colors=ButtonDefaults.buttonColors(containerColor=Lime, contentColor=Ink), modifier=Modifier.fillMaxWidth()) {
                        Text("MANAGE YOUR SQUAD", fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        item {
            Text("QUICK ACCESS", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.5.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                QuickTile("Live Auction",Icons.Default.Gavel,Modifier.weight(1f)){onNavigate("Auction")}
                QuickTile("World Leagues",Icons.Default.Public,Modifier.weight(1f)){onNavigate("World")}
                QuickTile("Match Centre",Icons.Default.SportsCricket,Modifier.weight(1f)){onNavigate("Match")}
            }
        }
        item {
            SectionHeader("RCB LEGENDS", "20-player legacy roster")
            val stars = store.rcbPlayers().sortedByDescending { it.ovr }.take(5)
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                stars.forEach { PlayerRow(it) }
            }
        }
        item {
            SectionHeader("LATEST CAREER UPDATE","Season ${store.season}")
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
                Text(store.lastResult, Modifier.padding(16.dp), color=White, fontSize=13.sp)
            }
        }
        item {
            SectionHeader("ONLINE UNIVERSE","Offline-first career")
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudOff, null, tint=Gold)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Cloud services not connected", color=White, fontWeight=FontWeight.Bold)
                        Text("Your career saves locally. Online accounts, cross-device sync and multiplayer need a backend connection before release.", color=Muted, fontSize=11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.StatPill(label:String,value:String) {
    Column(Modifier.weight(1f).background(Ink.copy(alpha=.45f), RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label,color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
        Text(value,color=White,fontSize=14.sp,fontWeight=FontWeight.Black)
    }
}

@Composable
fun QuickTile(title:String,icon: androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier, click:()->Unit) {
    Column(modifier.background(Panel, RoundedCornerShape(15.dp)).clickable { click() }.padding(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Icon(icon,null,tint=Lime,modifier=Modifier.size(24.dp))
        Spacer(Modifier.height(7.dp))
        Text(title,color=White,fontSize=10.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}

@Composable
fun SectionHeader(title:String, subtitle:String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.Bottom) {
        Text(title,color=White,fontSize=15.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
        Text(subtitle,color=Muted,fontSize=10.sp)
    }
    Spacer(Modifier.height(9.dp))
}

@Composable
fun SquadScreen(store:GameStore) {
    var filter by remember { mutableStateOf("All") }
    val players=store.rcbPlayers().filter { filter=="All" || it.role==filter }.sortedByDescending { it.ovr }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("RCB SQUAD ROOM",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
        Text("The Red & Gold",color=White,fontSize=27.sp,fontWeight=FontWeight.Black)
        Text("${store.rcbNames.size}/30 players  •  ₹${"%.3f".format(store.purse)} Cr remaining",color=Lime,fontSize=12.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("All","Batter","Bowler","All-rounder","Wicketkeeper").forEach { role ->
                FilterChip(selected=filter==role,onClick={filter=role},label={Text(role,fontSize=10.sp)})
            }
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=12.dp)) {
            items(players) { PlayerRow(it) }
        }
    }
}

@Composable
fun PlayerRow(player:Cricketer) {
    Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(14.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Panel2,CircleShape),contentAlignment=Alignment.Center) {
            Text(player.name.split(" ").take(2).mapNotNull { it.firstOrNull() }.joinToString(""),color=Lime,fontWeight=FontWeight.Black)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(player.name,color=White,fontWeight=FontWeight.Bold,fontSize=13.sp)
            Text("${player.country} • ${player.role}",color=Muted,fontSize=10.sp)
            if (player.note.isNotBlank()) Text(player.note,color=Gold,fontSize=9.sp)
        }
        Column(horizontalAlignment=Alignment.End) {
            Text("${player.ovr}",color=if(player.ovr>=99)Lime else White,fontSize=20.sp,fontWeight=FontWeight.Black)
            Text("OVR",color=Muted,fontSize=9.sp)
        }
    }
}

@Composable
fun AuctionScreen(store:GameStore,notice:(String)->Unit) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Cricketer?>(null) }
    val free=store.freeAgents().filter { query.isBlank() || it.name.contains(query,true) || it.country.contains(query,true) }
        .sortedByDescending { it.ovr }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("GLOBAL PLAYER MARKET",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
        Text("The Auction Room",color=White,fontSize=27.sp,fontWeight=FontWeight.Black)
        Text("RCB purse • ₹${"%.3f".format(store.purse)} Cr",color=Lime,fontSize=13.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),
            placeholder={Text("Search player or country")},leadingIcon={Icon(Icons.Default.Search,null)},
            singleLine=true,colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Lime,unfocusedBorderColor=Muted))
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=90.dp)) {
            items(free) { p ->
                Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(14.dp)).clickable { selected=p }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name,color=White,fontWeight=FontWeight.Bold,fontSize=13.sp)
                        Text("${p.country} • ${p.role}",color=Muted,fontSize=10.sp)
                    }
                    Column(horizontalAlignment=Alignment.End) {
                        Text("OVR ${p.ovr}",color=Lime,fontWeight=FontWeight.Black)
                        Text("₹${"%.2f".format(p.price)} Cr",color=Muted,fontSize=10.sp)
                    }
                }
            }
        }
    }
    selected?.let { p ->
        AlertDialog(
            onDismissRequest={selected=null},
            containerColor=Panel,
            title={Text("AUCTION LOT",color=Lime,fontWeight=FontWeight.Black)},
            text={Column { Text(p.name,color=White,fontWeight=FontWeight.Bold); Text("${p.country} • ${p.role} • OVR ${p.ovr}",color=Muted); Text("Starting price: ₹${"%.2f".format(p.price)} Cr",color=White) }},
            confirmButton={
                TextButton2("SIGN FOR RCB") {
                    notice(store.sign(p)); selected=null
                }
            },
            dismissButton={TextButton2("CANCEL"){selected=null}}
        )
    }
}

@Composable
fun WorldScreen() {
    var selectedLeague by remember { mutableStateOf("All") }
    val leagues=listOf("All","IPL","BBL","PSL","SA20","CPL","ILT20","MLC","WPL","WBBL","The Hundred")
    val visible=clubs.filter { selectedLeague=="All" || it.league==selectedLeague }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("THE GLOBAL GAME",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
        Text("World Leagues",color=White,fontSize=27.sp,fontWeight=FontWeight.Black)
        Text("${clubs.size} clubs • ${leagues.size-1} featured competitions",color=Lime,fontSize=12.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            leagues.take(6).forEach { FilterChip(selected=selectedLeague==it,onClick={selectedLeague=it},label={Text(it,fontSize=10.sp)}) }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            leagues.drop(6).forEach { FilterChip(selected=selectedLeague==it,onClick={selectedLeague=it},label={Text(it,fontSize=10.sp)}) }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(visible) { club ->
                Row(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(13.dp)).padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Panel2,CircleShape),contentAlignment=Alignment.Center) {
                        Text(club.code.take(3),color=Lime,fontWeight=FontWeight.Black,fontSize=11.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(club.name,color=White,fontWeight=FontWeight.Bold,fontSize=12.sp)
                        Text(club.league,color=Muted,fontSize=10.sp)
                    }
                    Icon(Icons.Default.ChevronRight,null,tint=Muted)
                }
            }
        }
    }
}

@Composable
fun MatchScreen(store:GameStore,notice:(String)->Unit) {
    var overs by remember { mutableIntStateOf(20) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("MATCH DAY",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)
        Text("Match Centre",color=White,fontSize=27.sp,fontWeight=FontWeight.Black)
        Text("Choose a format and simulate your next fixture.",color=Muted,fontSize=12.sp)
        Spacer(Modifier.height(18.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("UPCOMING FIXTURE",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.4.sp)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                    TeamBadge("RCB")
                    Text("VS",color=Gold,fontWeight=FontWeight.Black,fontSize=18.sp)
                    TeamBadge("MI")
                }
                Spacer(Modifier.height(15.dp))
                Text("FORMAT",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf(5,10,20).forEach { n ->
                        FilterChip(selected=overs==n,onClick={overs=n},label={Text("$n overs")})
                    }
                }
                Spacer(Modifier.height(15.dp))
                Button(onClick={notice(store.simulateQuickMatch())},modifier=Modifier.fillMaxWidth(),
                    colors=ButtonDefaults.buttonColors(containerColor=Lime,contentColor=Ink)) {
                    Icon(Icons.Default.PlayArrow,null)
                    Spacer(Modifier.width(6.dp))
                    Text("SIMULATE MATCH",fontWeight=FontWeight.Black)
                }
                Text("Quick-result prototype. Full ball-by-ball tactical control is planned for the next match-engine milestone.",color=Muted,fontSize=10.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        SectionHeader("LATEST RESULT","Career log")
        Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)) {
            Text(store.lastResult,Modifier.padding(16.dp),color=White,fontSize=13.sp)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick={store.resetSeason();notice("Season ${store.season} created. Your RCB career has advanced.")},
            colors=ButtonDefaults.buttonColors(containerColor=Panel2,contentColor=Lime),modifier=Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Flag,null); Spacer(Modifier.width(8.dp)); Text("START NEXT SEASON")
        }
    }
}

@Composable
fun TeamBadge(code:String) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).background(Lime,CircleShape),contentAlignment=Alignment.Center) {
            Text(code,color=Ink,fontWeight=FontWeight.Black,fontSize=17.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(if(code=="RCB") "BENGALURU" else "MUMBAI",color=White,fontWeight=FontWeight.Bold,fontSize=11.sp)
    }
}
